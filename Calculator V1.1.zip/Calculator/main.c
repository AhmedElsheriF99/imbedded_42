/*
Calculator App
*/
#include <stdio.h>

int main()
{
    printf("************************ the calculator app ************************\n");
    float num_one;
    float num_two;
    int oper;

    printf("type number one :");
    scanf(" %f",&num_two);

    printf("type number two :");
    scanf(" %f",&num_one);
    /* the operation
    */
    printf("[1] = +\n");
    printf("[2] = -\n");
    printf("[3] = *\n");
    printf("[4] = /\n");
    printf("choose the operation.\n");
    scanf(" %d",&oper);
    /*user will choose number the operation
    */
    switch(oper)
    {
        case 1:
            printf("%f + %f = %f\n",num_one, num_two,num_one + num_two);
        break;

        case 2:
            printf("%f - %f = %f\n",num_one, num_two,num_one - num_two);
        break;

        case 3:
            printf("%f * %f = %f\n",num_one, num_two,num_one * num_two);
        break;

        case 4:
            printf("%f / %f = %f\n",num_one, num_two,num_one / num_two);
        break;

        default:
        printf("operation is not valid\n");//If the user chose the wrong number for the operation

    return 0;
    }
}
