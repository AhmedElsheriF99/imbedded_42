/*
Calculator App
*/
#include <stdio.h>

int main()
{
    printf("************************ the calculator app ************************\n");
    int num_one;
    int num_two;
    int oper;

    printf("type number one :");
    scanf(" %d",&num_two);

    printf("type number two :");
    scanf(" %d",&num_one);

    printf("[1] = +\n"); // the operation
    printf("[2] = -\n");
    printf("[3] = *\n");
    printf("[4] = /\n");
    printf("choose the operation.\n");
    scanf(" %d",&oper);

    if(oper == 1)
    {
        printf("%d + %d = %d\n",num_one, num_two,num_one + num_two);
    }
    else if(oper == 2)
    {
        printf("%d - %d = %d\n",num_one, num_two,num_one - num_two);
    }
    else if(oper == 3)
    {

        printf("%d * %d = %d\n",num_one, num_two,num_one * num_two);
    }
    else if(oper == 4)
    {
        printf("%d / %d = %d\n",num_one, num_two,num_one / num_two);
    }
    else
    {
        printf("operation is not valid\n");
    }


    return 0;
}
